package com.example.sproje;

public class Goal {
    private String goalName;
    private String goalDescription;
    private String startDate;
    private String endDate;
    private int dailyGoal;
}
