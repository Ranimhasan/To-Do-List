package com.example.sproje;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ItemGoalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_goal);
    }
}